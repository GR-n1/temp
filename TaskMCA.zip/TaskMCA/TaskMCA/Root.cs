namespace TaskMCA
{
    public class Root
    {
        public string? name { get; set; }
        public bool domestic { get; set; }
        public double price { get; set; }
        public int? weight { get; set; }
        public string? description { get; set; }
    }
}